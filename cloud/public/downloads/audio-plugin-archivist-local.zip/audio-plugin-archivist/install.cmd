@echo off
cd /d "%~dp0"
call conda create -n audio-plugin-archivist python=3.12 pip -y
if errorlevel 1 goto fail
call conda run -n audio-plugin-archivist python -m pip install -e .
if errorlevel 1 goto fail
echo Installation complete. Run start.cmd
pause
exit /b 0
:fail
echo Installation failed. Run from Miniconda Prompt and check the message above.
pause
exit /b 1
