@echo off
cd /d "%~dp0"
call conda run --no-capture-output -n audio-plugin-archivist python -m audio_archive serve --open
if errorlevel 1 pause
